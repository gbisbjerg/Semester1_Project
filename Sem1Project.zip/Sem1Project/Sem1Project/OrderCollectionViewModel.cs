﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Sem1Project.Annotations;
using System.Windows.Input;

namespace Sem1Project
{
    class OrderCollectionViewModel : INotifyPropertyChanged  //Need to create different viewmodels for different pages, stop using domainobject its messes up static counter
    {
        private OrderCollection _orders = OrderCollection.GetOrderCollection;
        private OrderClass _domainObject;   //Creates temp object to store information on OrderPage.. Needs to use varriable I future to fix static counter
        private RelayCommand _AddCommand;


        public OrderCollectionViewModel()
        {
            _AddCommand = new RelayCommand(DoAddRelay, OrderDomainObject);
            _domainObject = new OrderClass();
        }

        public string Company
        {
            get { return _domainObject.Company; }
            set
            {
                _domainObject.Company = value;
                OnPropertyChanged();
            }
        }

        public string Product
        {
            get { return _domainObject.Product; }
            set
            {
                _domainObject.Product = value;
                OnPropertyChanged();
            }
        }

        public string Description
        {
            get { return _domainObject.Description; }
            set
            {
                _domainObject.Description = value;
                OnPropertyChanged();
            }
        }

        public string Price
        {
            get { return _domainObject.Price; }
            set
            {
                _domainObject.Price = value; 
                OnPropertyChanged();
            }
        }

        public ObservableCollection<OrderClass> Orders   //Should remove
        {
            get { return _orders.Orders; }
        }


        //--------------------------------------Below of code for add order need to be cleaned up and relocated-------------------
        public bool DoAdd()
        {
            //return (_domainObject != new OrderClass() && AddOrder());  //bool   //change product to item id later
            AddOrder();
            return true;
        }

        public void DoAddRelay()
        {
            DoAdd();
        }

        public bool OrderDomainObject()
        {
            //return _domainObject != new OrderClass();
            return true;
        }

        public ICommand AddCommand
        {
            get { return _AddCommand; }
        }

        public bool AddOrder()
        {
            _orders.AddOrder(_domainObject);
            OnPropertyChanged();
            return true;
        }



        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
