﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Windows.Devices.Bluetooth.Advertisement;
using Sem1Project.Annotations;

namespace Sem1Project
{
    public sealed class OrderCollection : INotifyPropertyChanged  //Methods to sort lists, use selectedorder to display information of order to user
    {
        private ObservableCollection<OrderClass> _orders;
        private OrderClass _selectedOrder;

        private static OrderCollection _instance;  //Singleton

        public OrderCollection()
        {
             DummyInfo dummyInfo = new DummyInfo();  //This should be stored data in future
            _orders = dummyInfo.StartInfo();
        }

        public static OrderCollection GetOrderCollection  //Singlton
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new OrderCollection();  //Generates new OrderCollection on first call
                }
                return _instance;
            }
        }

        public OrderClass SelectedOrder
        {
            get { return _selectedOrder; }
            set { _selectedOrder = value; }
        }

        public ObservableCollection<OrderClass> Orders
        {
            get { return _orders; }
        }

        public void AddOrder(OrderClass newOrder)
        {
            _orders.Add(newOrder);
            OnPropertyChanged();
        }

        public void RemoveItem(OrderClass order)  //Needs proper implementation
        {
            if (_orders.Contains(order))
            {
                _orders.Remove(order);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
