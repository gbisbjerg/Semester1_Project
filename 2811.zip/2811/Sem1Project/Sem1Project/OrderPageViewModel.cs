﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Sem1Project.Annotations;
using System.Windows.Input;

namespace Sem1Project
{
    class OrderPageViewModel : INotifyPropertyChanged  //Need to create different viewmodels for different pages
    {
        private OrderCollection _orders = OrderCollection.GetOrderCollection;
        private AddCommand _addCommand;
  
        public OrderPageViewModel()
        {
            _addCommand = new AddCommand();

            if (_orders.NewOrder == null)  //ADD
            {
                _orders.NewOrder = new OrderClass();
            }
            EditNewOrder();  //ADD  (currently clears neworder from last time page was open)

        }

        //These are temporary varriable that will be used to create a new object when the save button is used. 
        private string _company;
        private string _product;
        private string _description;
        private string _price;


        public string Company
        {
            get { return _company; }
            set
            {
                _company = value;
                EditNewOrder();
                OnPropertyChanged();
            }
        }

        public string Product
        {
            get { return _product; }
            set
            {
                _product = value;
                EditNewOrder();
                OnPropertyChanged();
            }
        }

        public string Description
        {
            get { return _description; }
            set
            {
                _description = value;
                EditNewOrder();
                OnPropertyChanged();
            }
        }

        public string Price
        {
            get { return _price; }
            set
            {
                _price = value; 
                EditNewOrder();
                OnPropertyChanged();
            }
        }

        public ObservableCollection<OrderClass> Orders  
        {
            get { return _orders.Orders; }
        }


        //Add
        public void EditNewOrder()
        {
            _orders.NewOrder.Company = _company;
            _orders.NewOrder.Description = _description;
            _orders.NewOrder.Price = _price;
            _orders.NewOrder.Product = _product;

            _addCommand.RaiseCanExecuteChanged();

        }

        public ICommand AddCommand
        {
            get
            {
                return _addCommand;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
