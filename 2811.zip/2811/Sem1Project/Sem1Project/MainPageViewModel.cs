﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Sem1Project.Annotations;

namespace Sem1Project
{
    class MainPageViewModel: INotifyPropertyChanged
    {
        private OrderCollection _orders = OrderCollection.GetOrderCollection;
        private DeleteCommand _deleteCommand;

        public MainPageViewModel()
        {

            _deleteCommand = new DeleteCommand();
            _orders.SelectedOrder = null;

        }

        public ObservableCollection<OrderClass> Orders
        {
            get { return _orders.Orders; }
        }

        public OrderClass SelectedOrder
        {
            get { return _orders.SelectedOrder; }
            set
            {
                _orders.SelectedOrder = value;
                OnPropertyChanged();
                _deleteCommand.RaiseCanExecuteChanged();
            }
        }

        public ICommand DeletionCommand
        {
            get { return _deleteCommand; }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

        }
    }
}
