﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Windows.Devices.Bluetooth.Advertisement;
using Sem1Project.Annotations;

namespace Sem1Project
{
    public sealed class OrderCollection  //Methods to sort lists
    {
        private ObservableCollection<OrderClass> _orders;
        private OrderClass _selectedOrder;
        private OrderClass _newOrder = null; //Must only create a pending new order after the last one was used..... creation is in order-collection-viewmodel

        private static OrderCollection _instance;  //Singleton

        public OrderCollection()
        {
             DummyInfo dummyInfo = new DummyInfo();  //This should be stored data in future
            _orders = dummyInfo.StartInfo();
        }

        public static OrderCollection GetOrderCollection  //Singlton
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new OrderCollection();  //Generates new OrderCollection on first call ONLY
                }
                return _instance;
            }
        }

        public OrderClass SelectedOrder
        {
            get { return _selectedOrder; }
            set { _selectedOrder = value; }
        }

        public ObservableCollection<OrderClass> Orders
        {
            get { return _orders; }
        }


        public OrderClass NewOrder
        {
            get { return _newOrder; }
            set { _newOrder = value; }
        }

        public void AddOrder(OrderClass order)
        {
            _orders.Add(order);
        }

        public void Delete(OrderClass order)
        {
            if (_orders.Contains(order))
            {
                _orders.Remove(order);
            }
        }

    }
}
