﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Sem1Project
{
    public class AddCommand : ICommand
    {
        private OrderCollection _orders;

        public AddCommand()
        {
            _orders = OrderCollection.GetOrderCollection;
        }

        public bool CanExecute(object parameter) 
        {
            return true;         //Need to change equivilance for OrderClass to allow for ordernumber to be compare if order is not blank???
        }

        public void Execute(object parameter)
        {
            // Add to catalog
            _orders.AddOrder(_orders.NewOrder);
            _orders.NewOrder = null;    //ADD
        }

        public void RaiseCanExecuteChanged()
        {
            CanExecuteChanged?.Invoke(this, EventArgs.Empty);
        }

        public event EventHandler CanExecuteChanged;
    }
}
