﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sem1Project
{
    class DummyInfo
    {
        public ObservableCollection<OrderClass> StartInfo()   
        //Just demo information to simulate previously stored data
        {
            ObservableCollection<OrderClass> _startInfo = new ObservableCollection<OrderClass>();

            OrderClass order1 = new OrderClass();
            order1.Product = "Phone";
            order1.Price = "1234";
            order1.Description = "hella good";
            order1.Company = "Apple";
            _startInfo.Add(order1);

            OrderClass order2 = new OrderClass();
            order2.Product = "fruit";
            order2.Price = "2";
            order2.Description = "hella good ehh";
            order2.Company = "Banana";
            _startInfo.Add(order2);

            return _startInfo;
        }

    }
}
