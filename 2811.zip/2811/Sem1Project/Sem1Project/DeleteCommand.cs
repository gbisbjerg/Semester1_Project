﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Sem1Project
{
    public class DeleteCommand : ICommand
    {
        private OrderCollection _orders;

        public DeleteCommand()
        {
            _orders = OrderCollection.GetOrderCollection;
        }

        public bool CanExecute(object parameter)
        {
            return _orders.SelectedOrder != null;
        }

        public void Execute(object parameter)
        {
            // Delete from catalog
            _orders.Delete(_orders.SelectedOrder);

            // Set selection to null
            _orders.SelectedOrder = null;
        }

        public void RaiseCanExecuteChanged()
        {
            CanExecuteChanged?.Invoke(this, EventArgs.Empty);
        }

        public event EventHandler CanExecuteChanged;
    }
}
