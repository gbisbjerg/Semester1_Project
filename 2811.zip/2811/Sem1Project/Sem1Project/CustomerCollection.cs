﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sem1Project
{
    public sealed class CustomerCollection
    {
        private ObservableCollection<Customer> _customers;
        private Customer _selectedCustomer;

        private static OrderCollection _instance;  //Singleton

        private CustomerCollection()
        {
            _customers = new ObservableCollection<Customer>();  //Should be replaced with dummyinfo
        }

        public static OrderCollection GetOrderCollection  //Singlton
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new OrderCollection();  //Generates new OrderCollection on first call
                }
                return _instance;
            }
        }

        public Customer SelectedOrder
        {
            get { return _selectedCustomer; }
            set { _selectedCustomer = value; }
        }

        public ObservableCollection<Customer> Orders
        {
            get { return _customers; }
        }

    }
}
