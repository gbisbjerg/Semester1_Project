﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sem1Project
{
    public class Customer
    {
        private string _company;
        private string _contactPerson;
        private string _address;
        private string _zipcode;
        private string _phoneNumber;
        private string _email;
        private string _companyNumber;

        public Customer()
        {
        }

        public string Company
        {
            get => _company;
            set => _company = value; 
        }

        public string ContactPerson
        {
            get => _contactPerson;
            set => _contactPerson = value;
        }

        public string Address
        {
            get => _address;
            set => _address = value;
        }

        public string Zipcode
        {
            get => _zipcode;
            set => _zipcode = value;
        }

        public string PhoneNumber
        {
            get => _phoneNumber;
            set => _phoneNumber = value;
        }

        public string Email
        {
            get => _email;
            set => _email = value;
        }

        public string CompanyNumber
        {
            get => _companyNumber;
            set => _companyNumber = value;
        }
    }
}
